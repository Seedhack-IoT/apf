from grovepi import *

try:
	[ temp, hum ] = dht(8,1)
	print temp, ",", hum

except (IOError,TypeError) as e:
	print "null"

