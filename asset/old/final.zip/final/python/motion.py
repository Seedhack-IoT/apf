from grovepi import *

try:
	print analogRead(0)

except (IOError,TypeError) as e:
	print "Error"

