// Setup basic express server
var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io')(server);
var port = process.env.PORT || 3000;

server.listen(port, function () {
  console.log('Server listening at port %d', port);
});

// Routing
app.use(express.static(__dirname + '/public'));

devices = [{"name":"Motion"},{"name":"Temp"}, {"name":"Humidity"}];

var PythonShell = require('python-shell');

var options = {
  scriptPath: '/home/pi/final/python/'
};

io.on('connection', function (socket) {
	socket.on('login', function (data) {
		socket.emit('logged in', {
		  devices:devices
		});
	})
	setInterval(function(){
		
		PythonShell.run('motion.py', options, function (err, data) {
		  if (err) throw err;
		  // console.log("Motion: ",parseInt(data[0]));
		  if (data){
		  	socket.emit("update", {
				"name":"Motion",
				"value":parseInt(data[0])
			})
		  }
		});
		
	},500);
	setInterval(function(){
		PythonShell.run('temp.py', options, function (err, data) {
		  if (err) throw err;
		  if (data){
		  	var arr = data[0].split(",");
		  	var temp = arr[0];
		  	var hum = arr[1];
		  	if (parseInt(temp)!=0){
		  		socket.emit("update", {
				"name":"Temp",
				"value":temp
		  	})	
		  	}
		  	if (parseInt(hum)!=0){
			  	socket.emit("update", {
					"name":"Humidity",
					"value":hum
			  	})
			}	
		  }
		  
		});
		
	},500);
})

